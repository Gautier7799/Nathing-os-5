# Nothing OS 5 Launcher — Safe Improvements

This revision keeps the existing UI, widgets, themes, gestures, lock screen, notification listener, and launcher features intact.

## Changes

- Android 17 / API 37 compile and target configuration.
- Java 17 Android compile compatibility.
- Modern `RoleManager.ROLE_HOME` request while retaining the existing HOME intent filter as fallback.
- `ACCESS_HIDDEN_PROFILES` declaration for modern launcher/private-space compatibility.
- Package-change receiver so the app drawer updates after install, uninstall, replace, or package changes.
- Existing Dock, pinned apps, and folders are preserved when the installed-app inventory refreshes.
- First-run/default layout behavior remains unchanged.
- No existing widget, theme, gesture, lock-screen, or visual component was removed.

## Android 17 readiness

Android 17 is API 37. Apps targeting API 37 should be tested for the platform behavior changes, especially memory use in RemoteViews/widgets and large-screen behavior.
